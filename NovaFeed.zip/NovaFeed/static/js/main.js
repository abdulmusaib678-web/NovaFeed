document.addEventListener('DOMContentLoaded', function() {
    initDarkMode();
    initFlashMessages();
    initImageLoading();
    initLikeButtons();
    initComments();
});

function initDarkMode() {
    const darkModeToggle = document.getElementById('darkModeToggle');
    if (!darkModeToggle) return;
    
    const isDarkMode = localStorage.getItem('darkMode') === 'true';
    if (isDarkMode) {
        document.body.classList.add('dark-mode');
        darkModeToggle.querySelector('i').classList.replace('fa-moon', 'fa-sun');
    }
    
    darkModeToggle.addEventListener('click', function() {
        document.body.classList.toggle('dark-mode');
        const isDark = document.body.classList.contains('dark-mode');
        localStorage.setItem('darkMode', isDark);
        
        const icon = this.querySelector('i');
        if (isDark) {
            icon.classList.replace('fa-moon', 'fa-sun');
        } else {
            icon.classList.replace('fa-sun', 'fa-moon');
        }
    });
}

function initFlashMessages() {
    const flashMessages = document.querySelectorAll('.flash-message');
    
    flashMessages.forEach(message => {
        const closeBtn = message.querySelector('.flash-close');
        
        closeBtn.addEventListener('click', function() {
            message.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => message.remove(), 300);
        });
        
        setTimeout(() => {
            if (message.parentElement) {
                message.style.animation = 'slideOut 0.3s ease';
                setTimeout(() => message.remove(), 300);
            }
        }, 5000);
    });
}

function initImageLoading() {
    const images = document.querySelectorAll('.post-image');
    
    images.forEach(img => {
        if (img.complete) {
            img.classList.add('loaded');
            img.classList.remove('loading');
        } else {
            img.addEventListener('load', function() {
                this.classList.add('loaded');
                this.classList.remove('loading');
            });
        }
    });
}

function initLikeButtons() {
    const likeButtons = document.querySelectorAll('.like-btn');
    
    likeButtons.forEach(btn => {
        btn.addEventListener('click', async function() {
            const postId = this.dataset.postId;
            const icon = this.querySelector('i');
            const likeCountElement = this.closest('.post-card').querySelector('.like-count');
            
            try {
                const response = await fetch('/api/like', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ post_id: postId })
                });
                
                const data = await response.json();
                
                if (data.liked) {
                    this.classList.add('liked');
                    icon.classList.replace('far', 'fas');
                    icon.style.color = '#ed4956';
                } else {
                    this.classList.remove('liked');
                    icon.classList.replace('fas', 'far');
                    icon.style.color = '';
                }
                
                likeCountElement.textContent = data.like_count;
                
                const likesText = this.closest('.post-card').querySelector('.post-likes');
                likesText.innerHTML = `<strong class="like-count">${data.like_count}</strong> like${data.like_count !== 1 ? 's' : ''}`;
                
            } catch (error) {
                console.error('Error liking post:', error);
            }
        });
    });
}

function initComments() {
    const viewCommentsLinks = document.querySelectorAll('.view-comments');
    
    viewCommentsLinks.forEach(link => {
        link.addEventListener('click', async function(e) {
            e.preventDefault();
            const postId = this.dataset.postId;
            const commentsList = document.getElementById(`comments-${postId}`);
            
            if (commentsList.style.display === 'none') {
                try {
                    const response = await fetch(`/api/get_comments/${postId}`);
                    const comments = await response.json();
                    
                    commentsList.innerHTML = '';
                    comments.forEach(comment => {
                        const commentDiv = document.createElement('div');
                        commentDiv.className = 'comment-item';
                        commentDiv.innerHTML = `<strong>${comment.username}</strong> ${comment.text} <span style="color: var(--text-secondary); font-size: 12px;">${comment.created_at}</span>`;
                        commentsList.appendChild(commentDiv);
                    });
                    
                    commentsList.style.display = 'block';
                    this.textContent = 'Hide comments';
                } catch (error) {
                    console.error('Error loading comments:', error);
                }
            } else {
                commentsList.style.display = 'none';
                const commentCount = this.textContent.match(/\d+/)[0];
                this.textContent = `View all ${commentCount} comment${commentCount !== '1' ? 's' : ''}`;
            }
        });
    });
    
    const commentSubmits = document.querySelectorAll('.comment-submit');
    
    commentSubmits.forEach(btn => {
        btn.addEventListener('click', async function() {
            const postId = this.dataset.postId;
            const input = document.querySelector(`.comment-input[data-post-id="${postId}"]`);
            const text = input.value.trim();
            
            if (!text) return;
            
            try {
                const response = await fetch('/api/comment', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ post_id: postId, text: text })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    input.value = '';
                    
                    const viewCommentsLink = document.querySelector(`.view-comments[data-post-id="${postId}"]`);
                    viewCommentsLink.textContent = `View all ${data.comment_count} comment${data.comment_count !== 1 ? 's' : ''}`;
                    
                    const commentsList = document.getElementById(`comments-${postId}`);
                    if (commentsList.style.display !== 'none') {
                        const commentDiv = document.createElement('div');
                        commentDiv.className = 'comment-item';
                        commentDiv.innerHTML = `<strong>${data.username}</strong> ${text} <span style="color: var(--text-secondary); font-size: 12px;">just now</span>`;
                        commentsList.insertBefore(commentDiv, commentsList.firstChild);
                    }
                }
            } catch (error) {
                console.error('Error posting comment:', error);
            }
        });
    });
    
    const commentInputs = document.querySelectorAll('.comment-input');
    commentInputs.forEach(input => {
        input.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                const postId = this.dataset.postId;
                document.querySelector(`.comment-submit[data-post-id="${postId}"]`).click();
            }
        });
    });
}
