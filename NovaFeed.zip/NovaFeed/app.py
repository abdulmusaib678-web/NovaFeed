import os
import sqlite3
import uuid
from datetime import datetime
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

app = Flask(__name__)
if not os.environ.get('SESSION_SECRET'):
    import warnings
    warnings.warn('SESSION_SECRET not set! Using development key. Set SESSION_SECRET for production.')
app.secret_key = os.environ.get('SESSION_SECRET', 'dev-secret-key-change-in-production')
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['REELS_FOLDER'] = 'static/reels'
app.config['MAX_CONTENT_LENGTH'] = 30 * 1024 * 1024

ALLOWED_IMAGE_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
ALLOWED_VIDEO_EXTENSIONS = {'mp4', 'mov', 'avi', 'webm'}
ALLOWED_EXTENSIONS = ALLOWED_IMAGE_EXTENSIONS | ALLOWED_VIDEO_EXTENSIONS

def allowed_file(filename, file_type='any'):
    if not filename or '.' not in filename:
        return False
    ext = filename.rsplit('.', 1)[1].lower()
    if file_type == 'image':
        return ext in ALLOWED_IMAGE_EXTENSIONS
    elif file_type == 'video':
        return ext in ALLOWED_VIDEO_EXTENSIONS
    return ext in ALLOWED_EXTENSIONS

def get_file_type(filename):
    if not filename or '.' not in filename:
        return None
    ext = filename.rsplit('.', 1)[1].lower()
    if ext in ALLOWED_IMAGE_EXTENSIONS:
        return 'image'
    elif ext in ALLOWED_VIDEO_EXTENSIONS:
        return 'video'
    return None

def get_db():
    conn = sqlite3.connect('novafeed.db')
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            profile_photo TEXT DEFAULT 'default-avatar.png',
            bio TEXT DEFAULT '',
            is_premium INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS posts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            media_path TEXT NOT NULL,
            media_type TEXT DEFAULT 'image',
            caption TEXT DEFAULT '',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ''')
    
    try:
        cursor.execute('SELECT is_premium FROM users LIMIT 1')
    except sqlite3.OperationalError:
        cursor.execute('ALTER TABLE users ADD COLUMN is_premium INTEGER DEFAULT 0')
    
    try:
        cursor.execute('SELECT media_path FROM posts LIMIT 1')
    except sqlite3.OperationalError:
        try:
            cursor.execute('ALTER TABLE posts RENAME COLUMN image_path TO media_path')
        except:
            cursor.execute('ALTER TABLE posts ADD COLUMN media_path TEXT')
            cursor.execute('UPDATE posts SET media_path = image_path WHERE media_path IS NULL')
    
    try:
        cursor.execute('SELECT media_type FROM posts LIMIT 1')
    except sqlite3.OperationalError:
        cursor.execute('ALTER TABLE posts ADD COLUMN media_type TEXT DEFAULT "image"')
        cursor.execute('UPDATE posts SET media_type = "image" WHERE media_type IS NULL')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS followers (
            follower_id INTEGER NOT NULL,
            following_id INTEGER NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (follower_id, following_id),
            FOREIGN KEY (follower_id) REFERENCES users(id),
            FOREIGN KEY (following_id) REFERENCES users(id)
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS likes (
            user_id INTEGER NOT NULL,
            post_id INTEGER NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (user_id, post_id),
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (post_id) REFERENCES posts(id)
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS comments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            post_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            text TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (post_id) REFERENCES posts(id),
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ''')
    
    conn.commit()
    conn.close()

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to access this page.', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def time_ago(timestamp):
    if isinstance(timestamp, str):
        dt = datetime.strptime(timestamp, '%Y-%m-%d %H:%M:%S')
    else:
        dt = timestamp
    
    now = datetime.now()
    diff = now - dt
    
    seconds = diff.total_seconds()
    
    if seconds < 60:
        return 'just now'
    elif seconds < 3600:
        minutes = int(seconds / 60)
        return f'{minutes} minute{"s" if minutes > 1 else ""} ago'
    elif seconds < 86400:
        hours = int(seconds / 3600)
        return f'{hours} hour{"s" if hours > 1 else ""} ago'
    elif seconds < 604800:
        days = int(seconds / 86400)
        return f'{days} day{"s" if days > 1 else ""} ago'
    elif seconds < 2592000:
        weeks = int(seconds / 604800)
        return f'{weeks} week{"s" if weeks > 1 else ""} ago'
    else:
        months = int(seconds / 2592000)
        return f'{months} month{"s" if months > 1 else ""} ago'

app.jinja_env.filters['time_ago'] = time_ago

@app.route('/')
@login_required
def home():
    conn = get_db()
    cursor = conn.cursor()
    
    user_id = session['user_id']
    
    cursor.execute('''
        SELECT posts.*, users.username, users.profile_photo, users.is_premium,
               (SELECT COUNT(*) FROM likes WHERE post_id = posts.id) as like_count,
               (SELECT COUNT(*) FROM comments WHERE post_id = posts.id) as comment_count,
               (SELECT COUNT(*) FROM likes WHERE post_id = posts.id AND user_id = ?) as user_liked
        FROM posts
        JOIN users ON posts.user_id = users.id
        WHERE posts.user_id IN (
            SELECT following_id FROM followers WHERE follower_id = ?
        ) OR posts.user_id = ?
        ORDER BY posts.created_at DESC
    ''', (user_id, user_id, user_id))
    
    posts = cursor.fetchall()
    
    cursor.execute('SELECT username FROM users WHERE id = ?', (user_id,))
    current_user = cursor.fetchone()
    
    conn.close()
    
    return render_template('home.html', posts=posts, current_user=current_user)

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        profile_photo = request.files.get('profile_photo')
        
        if not username or not email or not password:
            flash('All fields are required!', 'error')
            return redirect(url_for('signup'))
        
        conn = get_db()
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM users WHERE username = ? OR email = ?', (username, email))
        if cursor.fetchone():
            flash('Username or email already exists!', 'error')
            conn.close()
            return redirect(url_for('signup'))
        
        photo_filename = 'default-avatar.png'
        if profile_photo and profile_photo.filename and allowed_file(profile_photo.filename):
            ext = profile_photo.filename.rsplit('.', 1)[1].lower()
            safe_username = secure_filename(username)
            filename = f"{safe_username}_{uuid.uuid4().hex[:8]}.{ext}"
            profile_photo.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            photo_filename = filename
        
        password_hash = generate_password_hash(password)
        
        cursor.execute('''
            INSERT INTO users (username, email, password_hash, profile_photo)
            VALUES (?, ?, ?, ?)
        ''', (username, email, password_hash, photo_filename))
        
        conn.commit()
        conn.close()
        
        flash('Account created successfully! Please log in.', 'success')
        return redirect(url_for('login'))
    
    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        if not username or not password:
            flash('Username and password are required!', 'error')
            return redirect(url_for('login'))
        
        conn = get_db()
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM users WHERE username = ?', (username,))
        user = cursor.fetchone()
        
        conn.close()
        
        if user and check_password_hash(user['password_hash'], password):
            session['user_id'] = user['id']
            session['username'] = user['username']
            flash('Welcome back!', 'success')
            return redirect(url_for('home'))
        else:
            flash('Invalid username or password!', 'error')
            return redirect(url_for('login'))
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'success')
    return redirect(url_for('login'))

@app.route('/profile/<username>')
@login_required
def profile(username):
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM users WHERE username = ?', (username,))
    user = cursor.fetchone()
    
    if not user:
        flash('User not found!', 'error')
        return redirect(url_for('home'))
    
    cursor.execute('SELECT * FROM posts WHERE user_id = ? ORDER BY created_at DESC', (user['id'],))
    posts = cursor.fetchall()
    
    cursor.execute('SELECT COUNT(*) as count FROM followers WHERE following_id = ?', (user['id'],))
    followers_count = cursor.fetchone()['count']
    
    cursor.execute('SELECT COUNT(*) as count FROM followers WHERE follower_id = ?', (user['id'],))
    following_count = cursor.fetchone()['count']
    
    cursor.execute('SELECT * FROM followers WHERE follower_id = ? AND following_id = ?', 
                   (session['user_id'], user['id']))
    is_following = cursor.fetchone() is not None
    
    is_own_profile = session['user_id'] == user['id']
    
    conn.close()
    
    return render_template('profile.html', user=user, posts=posts, 
                         followers_count=followers_count, following_count=following_count,
                         is_following=is_following, is_own_profile=is_own_profile)

@app.route('/create', methods=['GET', 'POST'])
@login_required
def create():
    if request.method == 'POST':
        caption = request.form.get('caption', '')
        media = request.files.get('media')
        
        if not media or not media.filename or not allowed_file(media.filename):
            flash('Please upload a valid image or video!', 'error')
            return redirect(url_for('create'))
        
        media_type = get_file_type(media.filename)
        if not media_type:
            flash('Invalid file type!', 'error')
            return redirect(url_for('create'))
        
        ext = media.filename.rsplit('.', 1)[1].lower()
        safe_username = secure_filename(session['username'])
        filename = f"{safe_username}_{uuid.uuid4().hex}.{ext}"
        
        if media_type == 'video':
            upload_folder = app.config['REELS_FOLDER']
        else:
            upload_folder = app.config['UPLOAD_FOLDER']
        
        media.save(os.path.join(upload_folder, filename))
        
        conn = get_db()
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO posts (user_id, media_path, media_type, caption)
            VALUES (?, ?, ?, ?)
        ''', (session['user_id'], filename, media_type, caption))
        
        conn.commit()
        conn.close()
        
        flash('Post uploaded successfully!', 'success')
        return redirect(url_for('home'))
    
    return render_template('create.html')

@app.route('/reels')
@login_required
def reels():
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT posts.*, users.username, users.profile_photo, users.is_premium,
               (SELECT COUNT(*) FROM likes WHERE post_id = posts.id) as like_count,
               (SELECT COUNT(*) FROM comments WHERE post_id = posts.id) as comment_count,
               (SELECT COUNT(*) FROM likes WHERE post_id = posts.id AND user_id = ?) as user_liked
        FROM posts
        JOIN users ON posts.user_id = users.id
        WHERE posts.media_type = 'video'
        ORDER BY posts.created_at DESC
    ''', (session['user_id'],))
    
    reels = cursor.fetchall()
    conn.close()
    
    return render_template('reels.html', reels=reels)

@app.route('/chat')
@login_required
def chat():
    return render_template('chat.html')

@app.route('/search')
@login_required
def search():
    query = request.args.get('q', '')
    
    if query:
        conn = get_db()
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM users WHERE username LIKE ?', (f'%{query}%',))
        users = cursor.fetchall()
        
        conn.close()
        
        return render_template('search.html', users=users, query=query)
    
    return render_template('search.html', users=[], query='')

@app.route('/api/like', methods=['POST'])
@login_required
def like_post():
    data = request.get_json()
    post_id = data.get('post_id')
    
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM likes WHERE user_id = ? AND post_id = ?', 
                   (session['user_id'], post_id))
    like = cursor.fetchone()
    
    if like:
        cursor.execute('DELETE FROM likes WHERE user_id = ? AND post_id = ?', 
                      (session['user_id'], post_id))
        liked = False
    else:
        cursor.execute('INSERT INTO likes (user_id, post_id) VALUES (?, ?)', 
                      (session['user_id'], post_id))
        liked = True
    
    cursor.execute('SELECT COUNT(*) as count FROM likes WHERE post_id = ?', (post_id,))
    like_count = cursor.fetchone()['count']
    
    conn.commit()
    conn.close()
    
    return jsonify({'liked': liked, 'like_count': like_count})

@app.route('/api/comment', methods=['POST'])
@login_required
def add_comment():
    data = request.get_json()
    post_id = data.get('post_id')
    text = data.get('text')
    
    if not text or not text.strip():
        return jsonify({'success': False, 'error': 'Comment cannot be empty'}), 400
    
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('''
        INSERT INTO comments (post_id, user_id, text)
        VALUES (?, ?, ?)
    ''', (post_id, session['user_id'], text))
    
    cursor.execute('SELECT COUNT(*) as count FROM comments WHERE post_id = ?', (post_id,))
    comment_count = cursor.fetchone()['count']
    
    conn.commit()
    conn.close()
    
    return jsonify({'success': True, 'comment_count': comment_count, 'username': session['username']})

@app.route('/api/follow', methods=['POST'])
@login_required
def follow_user():
    data = request.get_json()
    following_id = data.get('user_id')
    
    if following_id == session['user_id']:
        return jsonify({'success': False, 'error': 'Cannot follow yourself'}), 400
    
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM followers WHERE follower_id = ? AND following_id = ?', 
                   (session['user_id'], following_id))
    follow = cursor.fetchone()
    
    if follow:
        cursor.execute('DELETE FROM followers WHERE follower_id = ? AND following_id = ?', 
                      (session['user_id'], following_id))
        following = False
    else:
        cursor.execute('INSERT INTO followers (follower_id, following_id) VALUES (?, ?)', 
                      (session['user_id'], following_id))
        following = True
    
    cursor.execute('SELECT COUNT(*) as count FROM followers WHERE following_id = ?', (following_id,))
    followers_count = cursor.fetchone()['count']
    
    conn.commit()
    conn.close()
    
    return jsonify({'following': following, 'followers_count': followers_count})

@app.route('/api/get_comments/<int:post_id>')
@login_required
def get_comments(post_id):
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT comments.*, users.username, users.profile_photo
        FROM comments
        JOIN users ON comments.user_id = users.id
        WHERE comments.post_id = ?
        ORDER BY comments.created_at DESC
    ''', (post_id,))
    
    comments = cursor.fetchall()
    conn.close()
    
    return jsonify([{
        'id': c['id'],
        'username': c['username'],
        'text': c['text'],
        'created_at': time_ago(c['created_at'])
    } for c in comments])

@app.route('/edit_profile', methods=['GET', 'POST'])
@login_required
def edit_profile():
    if request.method == 'POST':
        bio = request.form.get('bio', '')
        profile_photo = request.files.get('profile_photo')
        
        conn = get_db()
        cursor = conn.cursor()
        
        if profile_photo and profile_photo.filename and allowed_file(profile_photo.filename):
            ext = profile_photo.filename.rsplit('.', 1)[1].lower()
            safe_username = secure_filename(session['username'])
            filename = f"{safe_username}_profile_{uuid.uuid4().hex[:8]}.{ext}"
            profile_photo.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            
            cursor.execute('UPDATE users SET bio = ?, profile_photo = ? WHERE id = ?', 
                         (bio, filename, session['user_id']))
        else:
            cursor.execute('UPDATE users SET bio = ? WHERE id = ?', 
                         (bio, session['user_id']))
        
        conn.commit()
        conn.close()
        
        flash('Profile updated successfully!', 'success')
        return redirect(url_for('profile', username=session['username']))
    
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM users WHERE id = ?', (session['user_id'],))
    user = cursor.fetchone()
    conn.close()
    
    return render_template('edit_profile.html', user=user)

if __name__ == '__main__':
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    os.makedirs(app.config['REELS_FOLDER'], exist_ok=True)
    init_db()
    debug_mode = os.environ.get('FLASK_DEBUG', 'False').lower() == 'true'
    app.run(host='0.0.0.0', port=5000, debug=debug_mode)
