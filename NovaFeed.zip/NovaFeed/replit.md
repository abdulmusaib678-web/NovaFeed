# NovaFeed - Social Media Web Application

## Overview
NovaFeed is a complete, responsive social media web application inspired by Instagram. Built with Flask (Python) backend and modern HTML/CSS/JavaScript frontend, it provides a full-featured social networking experience with user authentication, posts, likes, comments, and follow functionality.

**Status**: Fully functional MVP deployed on Replit  
**Created**: November 1, 2025  
**Tech Stack**: Flask, SQLite, Pillow, Werkzeug, Vanilla JS, CSS3

## Core Features Implemented

### User System
- **Signup**: Username, email, password with profile photo upload
- **Login**: Secure authentication with password hashing (Werkzeug)
- **Logout**: Session management
- **Profile Pages**: Display user's posts in grid, bio, followers/following counts
- **Edit Profile**: Update bio and profile photo

### Post System
- **Create Post**: Upload images (JPG, PNG, GIF, WebP) or videos (MP4, MOV, AVI, WebM up to 30MB) with captions
- **Feed**: Dynamic feed showing posts from followed users (images and videos)
- **Reels**: Dedicated page for short-form video content with auto-play
- **Like/Unlike**: Instant updates with heart animation
- **Comments**: Add and view comments on posts
- **Relative Timestamps**: "2 hours ago" style timestamps

### Social Features
- **Follow/Unfollow**: Follow other users to see their posts
- **Search**: Search users by username
- **Profile Viewing**: Click on any user to view their profile

### UI/UX Features
- **Modern Design**: Instagram-inspired clean, minimal interface
- **Gradient Buttons**: #FF5F6D → #FFC371 gradient accents
- **Bottom Navigation**: Mobile-first gradient navbar with 6 icons (rounded top corners)
- **Dark Mode**: Toggle with localStorage persistence
- **Responsive**: Mobile-friendly navigation and layout (top nav hidden on mobile)
- **Smooth Animations**: CSS transitions on all elements (0.3s ease)
- **Flash Messages**: Success/error notifications
- **Premium Badges**: Green Star (🌟) with glow effect for premium users
- **Video Indicators**: Play button overlay on video thumbnails in grids

## Project Structure

```
NovaFeed/
├── app.py                    # Flask backend with all routes & database logic
├── novafeed.db              # SQLite database (auto-created)
├── static/
│   ├── uploads/             # User uploaded images & profile photos
│   │   └── default-avatar.png
│   ├── css/
│   │   └── style.css        # Main stylesheet with dark mode support
│   └── js/
│       └── main.js          # Client-side functionality (likes, comments, dark mode)
└── templates/
    ├── base.html            # Base template with navbar & footer
    ├── login.html           # Login page
    ├── signup.html          # Signup page
    ├── home.html            # Main feed
    ├── profile.html         # User profile page
    ├── edit_profile.html    # Edit profile form
    ├── create.html          # Create post page
    └── search.html          # User search page
```

## Database Schema

### users
- id (PRIMARY KEY)
- username (UNIQUE)
- email (UNIQUE)
- password_hash
- profile_photo (default: 'default-avatar.png')
- bio
- created_at

### posts
- id (PRIMARY KEY)
- user_id (FOREIGN KEY → users.id)
- image_path
- caption
- created_at

### followers
- follower_id (FOREIGN KEY → users.id)
- following_id (FOREIGN KEY → users.id)
- created_at
- PRIMARY KEY (follower_id, following_id)

### likes
- user_id (FOREIGN KEY → users.id)
- post_id (FOREIGN KEY → posts.id)
- created_at
- PRIMARY KEY (user_id, post_id)

### comments
- id (PRIMARY KEY)
- post_id (FOREIGN KEY → posts.id)
- user_id (FOREIGN KEY → users.id)
- text
- created_at

## API Endpoints

### Pages
- `GET /` - Home feed (login required)
- `GET/POST /login` - Login page
- `GET/POST /signup` - Signup page
- `GET /logout` - Logout and clear session
- `GET /profile/<username>` - User profile page
- `GET/POST /create` - Create new post (image or video)
- `GET /reels` - Video reels feed with auto-play
- `GET /chat` - Chat page (placeholder)
- `GET /search?q=<query>` - Search users
- `GET/POST /edit_profile` - Edit current user's profile

### API (JSON)
- `POST /api/like` - Like/unlike a post
- `POST /api/comment` - Add comment to post
- `POST /api/follow` - Follow/unfollow user
- `GET /api/get_comments/<post_id>` - Get all comments for a post

## Configuration

### Environment Variables
- `SESSION_SECRET` - Flask session secret key (REQUIRED for production)
  - Development: Auto-generated fallback with warning
  - Production: Must be set via Replit Secrets
- `FLASK_DEBUG` - Enable Flask debug mode (optional, defaults to `False`)
  - Development: Set to `true` for debug mode
  - Production: Leave unset or set to `false`

### Flask Settings
- Host: `0.0.0.0` (all interfaces)
- Port: `5000`
- Debug: Controlled by `FLASK_DEBUG` environment variable (defaults to `False`)
- Max Upload Size: `16MB`
- Upload Folder: `static/uploads`

### Production Deployment Checklist
1. Set `SESSION_SECRET` to a strong random value in Replit Secrets
2. Ensure `FLASK_DEBUG` is unset or set to `false`
3. Verify all uploaded images are accessible via `/static/uploads/`
4. Test user signup, login, post creation, and profile updates

## Design System

### Typography
- Font Family: 'Poppins' from Google Fonts
- Fallbacks: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto

### Color Palette
**Light Mode:**
- Background: #fafafa
- Cards: #ffffff
- Text: #262626
- Secondary Text: #8e8e8e
- Borders: #dbdbdb
- Primary Gradient: #FF5F6D → #FFC371

**Dark Mode:**
- Background: #000000
- Cards: #121212
- Text: #ffffff
- Secondary Text: #a8a8a8
- Borders: #2a2a2a
- Primary Gradient: #FF5F6D → #FFC371 (same)

### UI Components
- Rounded corners: 8px, 12px, 16px, 20px
- Card shadows: subtle with hover elevation
- Circular avatars: 50% border-radius
- Smooth transitions: 0.3s ease
- Gradient buttons with hover lift effect

## Security Features
- Password hashing with Werkzeug security
- Session-based authentication
- CSRF protection via Flask sessions
- File upload validation (type and size)
- Secure filename handling with `secure_filename()` to prevent path traversal
- UUID-based filenames to prevent collisions and ensure uniqueness
- SQL injection protection (parameterized queries)
- Debug mode disabled by default in production
- SESSION_SECRET validation with warnings

## Dependencies
```
flask==3.1.2
werkzeug==3.1.3
pillow==12.0.0
```

## Recent Changes
**November 1, 2025 - v1.1 (Finishing Features Complete)**
- **Bottom Navigation Bar**: Responsive gradient navbar (#FF5F6D → #FFC371) with Home, Search, Reels, Create, Chat, Profile icons
- **Reels Support**: Full video upload and playback with auto-play, loop, and Instagram-style overlay UI
- **Video Posts**: Support for MP4, MOV, AVI, WebM uploads (up to 30MB) alongside images
- **Premium Memberships**: Green Star badge system with glowing effect on profiles and posts
- **Chat Page**: Placeholder for future real-time messaging feature
- **Enhanced Create Page**: Auto-detection of image vs video with dual preview support
- **Smooth Transitions**: CSS transitions on all interactive elements
- **Mobile-First Design**: Bottom navbar replaces top nav on mobile screens
- **Database Migration**: Automatic schema updates for existing installations (image_path → media_path)

**November 1, 2025 - v1.0 (MVP Complete)**
- Initial project setup and complete MVP implementation
- All core features functional: auth, posts, likes, comments, follow system
- Modern responsive UI with dark mode support
- Production-ready Flask configuration for Replit deployment
- Security hardening:
  - Added `secure_filename()` sanitization to prevent path traversal attacks
  - UUID-based filenames for all uploads to prevent collisions
  - Debug mode now environment-controlled (defaults to off)
  - SESSION_SECRET validation with production warnings
  - Comprehensive file upload validation (type, size, filename)

## Future Enhancements
- Direct messaging system
- Story/Status feature (24-hour posts)
- Notification system for likes, comments, followers
- Explore page with trending posts
- Post saving/bookmarking
- Hashtag system and tag-based search
- Video upload support
- User verification badges
- Account privacy settings

## Notes
- Images are stored locally in `/static/uploads/`
- Database auto-initializes on first run
- Default avatar created automatically
- All routes except login/signup require authentication
- Feed shows only posts from followed users + own posts
- Relative timestamps update client-side for better UX
- Dark mode preference saved in browser localStorage
